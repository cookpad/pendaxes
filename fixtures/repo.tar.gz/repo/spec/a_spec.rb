describe "a" do
  context "b" do
    it "a" do
      pending
    end
  end

  context "c" do
    xit "d" do
      foo
      bar
    end
  end
end
